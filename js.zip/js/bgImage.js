const body = document.querySelector('body');

const IMG_NUM = 3;

function getRandomNumber() {
    const number = Math.ceil(Math.random() * 3);
    return number;
}

function init() {
    const randNumber = getRandomNumber();

    const image = new Image();
    image.src = `/images/${randNumber}.jpg`;

    image.classList.add('bgImage');
    body.appendChild(image);

}

init();
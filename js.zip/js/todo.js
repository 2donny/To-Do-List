const form_ToDo = document.querySelector('.js-form-toDo'),
    input_ToDo = form_ToDo.querySelector('input'),
    To_Do_List = document.querySelector('.to-do-list');

const TODOS_LS = "todos";

ToDos_arr = [];

function deleteToDo(event) {
    const target = event.target;
    const parentNode = target.parentNode;

    To_Do_List.removeChild(parentNode);
    const deletedToDos = ToDos_arr.filter((todo) => {
        return todo.id !== parseInt(parentNode.id);
    });
    ToDos_arr = deletedToDos;
    saveToDos();
}

function saveToDos() {
    const string_TOdos = JSON.stringify(ToDos_arr);
    localStorage.setItem(TODOS_LS, string_TOdos);
}

function paintToDo(text) {
    const li = document.createElement('li');
    const span = document.createElement('span');
    const btn = document.createElement('button');
    const newId = ToDos_arr.length + 1;

    btn.innerText = "❌";
    span.innerText = text;
    btn.addEventListener('click', deleteToDo);

    li.id = newId;
    li.classList.add('toDo');
    btn.classList.add('delBtn');

    li.appendChild(btn);
    li.appendChild(span);
    To_Do_List.appendChild(li);

    const todosObj = {
        id: newId,
        text: text,
    };
    ToDos_arr.push(todosObj);
    saveToDos();
}

function handleSubmit(event) {
    event.preventDefault();
    const rawText = input_ToDo.value;
    const text = rawText.trim();
    if(text) {
        paintToDo(text);
        input_ToDo.value = "";
    }
}

function loadTodos() {
    const loadedTodos = localStorage.getItem(TODOS_LS);
    console.log(loadedTodos);
    if (loadedTodos !== null) {
        const parsedTodos = JSON.parse(loadedTodos);
        parsedTodos.forEach(function (todo) {
            paintToDo(todo.text);
        });
    }
}
function init() {
    loadTodos();
    form_ToDo.addEventListener('submit', handleSubmit);
}

init();
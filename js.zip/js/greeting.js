const greeting_form = document.querySelector('.js-form-greeting')
    greeting_input = greeting_form.querySelector('input'),
    greeting_text = document.querySelector('.js-greeting-text');

const USER_LS = "currentName";

function saveCurrentName(text) {
    localStorage.setItem(USER_LS, text);
}

function handlerSubmit(event) {
    event.preventDefault();
    const currentName = greeting_input.value;
    paintName(currentName);
    saveCurrentName(currentName);
}

function askForName() {
    greeting_form.classList.add('showing');
    greeting_form.addEventListener('submit', handlerSubmit);
}

function paintName(text) {
    greeting_form.classList.remove('showing');
    greeting_text.classList.add('showing');
    greeting_text.innerText = `What's up ${text}`;
}

const loadName = () => {
    const loadedName = localStorage.getItem(USER_LS);

    if(loadedName) {
        paintName(loadedName);
    } else {
        askForName();
    }
}

function init() {
    loadName();
}

init();